import idPT from "pt-id"
import brNameGenerator from "br-name-generator"
import PDFDoc from "pdfkit"
import fs from "fs"

const doc = new PDFDoc;

console.log(idPT.nif.generate('personal'))
var nifP = idPT.nif.generate('personal')
console.log(idPT.nif.generate('company'))
var nifE = idPT.nif.generate('company')

console.log(idPT.cc.generate())
var cc =  idPT.cc.generate()



var nome = brNameGenerator(3)
console.log(nome[0])

doc.pipe(fs.createWriteStream('Ficheiros/Particular/'+nifP+'-'+nome[0].split(' ')[0]+'.pdf'));


doc
  .text('Numero de Identificação Fiscal: ' + nifP, {lineBreak: true});
// doc
//   .text('Numero de Identificação de Pessoa Colectiva : ' + nifE, {lineBreak: true});
doc
  .text('Cartão de Cidadão : ' + cc, {lineBreak: true});
doc
  .text('Data de Validade CC : 01-01-2030', {lineBreak: true});

doc
  .text('Nome Completo : ' + nome[0], {lineBreak: true});
doc
  .text('Data de Nascimento : 01-01-2000', {lineBreak: true});


doc
  .text('Nome Pai : ' + nome[1], {lineBreak: true});
doc
  .text('Nome Mãe : ' + nome[2], {lineBreak: true});


doc.end();