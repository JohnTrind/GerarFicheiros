import idPT from "pt-id"
import brNameGenerator from "br-name-generator"
import PDFDoc from "pdfkit"
import fs from "fs"

const doc = new PDFDoc;

console.log(idPT.nif.generate('personal'))
var nifP = idPT.nif.generate('personal')
console.log(idPT.nif.generate('company'))
var nifE = idPT.nif.generate('company')

console.log(idPT.cc.generate())
var cc =  idPT.cc.generate()

console.log(brNameGenerator()[0])

var nome = brNameGenerator()

doc.pipe(fs.createWriteStream('Ficheiros/Empresa/'+nifE+'-'+nome[0].split(' ')[0] +'&'+ nome[0].split(' ')[1] +  'Co'+'.pdf'));


doc
  .text('Numero de Identificação de Pessoa Colectiva : ' + nifE, {lineBreak: true});
doc
  .text('Denominação social : ' + nome[0].split(' ')[0] +'&'+ nome[0].split(' ')[1] +  'Co', {lineBreak: true});

doc.end();